$(document).ready(function() {
  //var s = $(".Titel").height();
  //var pos = s.position();        
  //var hnavbar = $(".navbar").height();  
//  $(".vlag").height($(".Titel").height()-20);
  });